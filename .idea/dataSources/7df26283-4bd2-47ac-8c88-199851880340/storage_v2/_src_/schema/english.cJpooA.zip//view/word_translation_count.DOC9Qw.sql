create view word_translation_count as
select `english`.`word`.`word_id`                   AS `word_id`,
       `english`.`word`.`word`                      AS `word`,
       count(`english`.`translation`.`translation`) AS `translationcount`
from ((`english`.`word` join `english`.`translate`)
         join `english`.`translation`)
where ((`english`.`word`.`word_id` = `english`.`translate`.`word_id`) and
       (`english`.`translation`.`trans_id` = `english`.`translate`.`trans_id`))
group by `english`.`word`.`word`;

