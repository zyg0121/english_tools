create
    definer = zyg@`%` procedure word_sentence(IN searchword varchar(40))
BEGIN
	SELECT `word`, `sentence` 
	from `instance` ,word, `sentence` 
	WHERE `instance`.`word_id` = `word`.`word_id` and `instance`.`sentence_id` = `sentence`.`sentence_id` and `word`.`word` = searchword;
END;

