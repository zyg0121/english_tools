create
    definer = zyg@`%` procedure word_translation(IN searchWord varchar(40))
BEGIN
	SELECT translation as 翻译
	FROM `word`, `translate`,  `translation`
	WHERE `word`.`word_id` = `translate`.`word_id` and `translation`.`trans_id` = `translate`.`trans_id` and `word`.`word` = searchWord;
END;

