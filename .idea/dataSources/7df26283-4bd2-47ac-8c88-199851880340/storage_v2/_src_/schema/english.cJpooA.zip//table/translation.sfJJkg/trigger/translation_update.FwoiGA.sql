create definer = zyg@`%` trigger translation_update
    before update
    on translation
    for each row
begin
    if not exists (select translation from translation where translation.translation = new.translation) then
        set new.translation = old.translation;
    end if;
end;

