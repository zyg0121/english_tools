create definer = zyg@`%` trigger word_update
    before update
    on word
    for each row
begin
    if not exists (select word from word where word.word = new.word) then
        set new.word = old.word;
    end if;
end;

