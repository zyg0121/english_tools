create view word_sentence_count as
select `english`.`word`.`word_id`             AS `word_id`,
       `english`.`word`.`word`                AS `word`,
       count(`english`.`sentence`.`sentence`) AS `sentencecount`
from ((`english`.`word` join `english`.`instance`)
         join `english`.`sentence`)
where ((`english`.`word`.`word_id` = `english`.`instance`.`word_id`) and
       (`english`.`instance`.`sentence_id` = `english`.`sentence`.`sentence_id`))
group by `english`.`word`.`word`;

